import 'dart:async';
import 'package:flutter/material.dart';
import '../models/user_status.dart';
import 'status_service.dart';

/// Service for automatically detecting user inactivity and changing status to Away
class AutoAwayService {
  static final AutoAwayService _instance = AutoAwayService._internal();
  factory AutoAwayService() => _instance;
  AutoAwayService._internal();

  final StatusService _statusService = StatusService();
  
  Timer? _inactivityTimer;
  DateTime _lastActivityTime = DateTime.now();
  StatusType? _previousStatus;
  bool _isEnabled = true;
  Duration _awayThreshold = const Duration(minutes: 5);
  
  /// Enable or disable auto-away detection
  bool get isEnabled => _isEnabled;
  set isEnabled(bool value) {
    _isEnabled = value;
    if (!value) {
      _stopMonitoring();
    } else {
      _startMonitoring();
    }
  }

  /// Get/set the inactivity threshold before changing to Away
  Duration get awayThreshold => _awayThreshold;
  set awayThreshold(Duration value) {
    _awayThreshold = value;
    if (_isEnabled) {
      _restartMonitoring();
    }
  }

  /// Start monitoring user activity
  void _startMonitoring() {
    _stopMonitoring();
    _lastActivityTime = DateTime.now();
    
    _inactivityTimer = Timer.periodic(
      const Duration(seconds: 30),
      (_) => _checkInactivity(),
    );
  }

  /// Stop monitoring user activity
  void _stopMonitoring() {
    _inactivityTimer?.cancel();
    _inactivityTimer = null;
  }

  /// Restart monitoring (used when threshold changes)
  void _restartMonitoring() {
    _stopMonitoring();
    _startMonitoring();
  }

  /// Check if user has been inactive and change status if needed
  Future<void> _checkInactivity() async {
    if (!_isEnabled) return;

    final now = DateTime.now();
    final inactiveDuration = now.difference(_lastActivityTime);

    if (inactiveDuration >= _awayThreshold) {
      // Get current status
      try {
        final currentStatus = await _statusService.getCurrentStatus();
        
        // Only change to Away if current status is Available
        if (currentStatus.type == StatusType.available) {
          _previousStatus = currentStatus.type;
          
          await _statusService.updateStatus(
            StatusType.away,
            'Auto-away after ${_awayThreshold.inMinutes} minutes',
          );
          
          debugPrint('[AutoAwayService] Changed status to Away due to inactivity');
        }
      } catch (e) {
        debugPrint('[AutoAwayService] Error checking/updating status: $e');
      }
    }
  }

  /// Record user activity (call this on any user interaction)
  void recordActivity() {
    _lastActivityTime = DateTime.now();
    
    // If user was auto-away, restore previous status
    _restorePreviousStatusIfNeeded();
  }

  /// Restore previous status if user was auto-away
  Future<void> _restorePreviousStatusIfNeeded() async {
    if (_previousStatus == null) return;

    try {
      final currentStatus = await _statusService.getCurrentStatus();
      
      // If current status is Away and we have a previous status, restore it
      if (currentStatus.type == StatusType.away && _previousStatus != null) {
        await _statusService.updateStatus(
          _previousStatus!,
          'Back from auto-away',
        );
        
        debugPrint('[AutoAwayService] Restored status to $_previousStatus');
        _previousStatus = null;
      }
    } catch (e) {
      debugPrint('[AutoAwayService] Error restoring status: $e');
    }
  }

  /// Initialize the service (call in app startup)
  void initialize() {
    if (_isEnabled) {
      _startMonitoring();
    }
  }

  /// Dispose the service (call in app shutdown)
  void dispose() {
    _stopMonitoring();
  }
}
