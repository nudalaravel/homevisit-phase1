import 'dart:async';
import 'package:flutter/material.dart';
import '../models/user_status.dart';
import '../models/auto_status_rule.dart';
import 'status_service.dart';

/// Service for scheduling automatic status changes based on time and day rules
class ScheduledStatusService {
  static final ScheduledStatusService _instance = ScheduledStatusService._internal();
  factory ScheduledStatusService() => _instance;
  ScheduledStatusService._internal();

  final StatusService _statusService = StatusService();
  
  Timer? _checkTimer;
  List<AutoStatusRule> _rules = [];
  bool _isEnabled = true;
  
  /// Enable or disable scheduled status changes
  bool get isEnabled => _isEnabled;
  set isEnabled(bool value) {
    _isEnabled = value;
    if (!value) {
      _stopMonitoring();
    } else {
      _startMonitoring();
    }
  }

  /// Get current rules
  List<AutoStatusRule> get rules => List.unmodifiable(_rules);

  /// Add a new rule
  void addRule(AutoStatusRule rule) {
    _rules.add(rule);
    _sortRules();
  }

  /// Remove a rule
  void removeRule(String ruleId) {
    _rules.removeWhere((rule) => rule.id == ruleId);
  }

  /// Update an existing rule
  void updateRule(AutoStatusRule updatedRule) {
    final index = _rules.indexWhere((rule) => rule.id == updatedRule.id);
    if (index != -1) {
      _rules[index] = updatedRule;
      _sortRules();
    }
  }

  /// Load rules from API
  Future<void> loadRules() async {
    try {
      // TODO: Load rules from API
      // final rules = await _statusService.getAutoStatusRules();
      // _rules = rules;
      // _sortRules();
      
      debugPrint('[ScheduledStatusService] Rules loaded: ${_rules.length}');
    } catch (e) {
      debugPrint('[ScheduledStatusService] Error loading rules: $e');
    }
  }

  /// Sort rules by priority (time-based rules first, then day-based)
  void _sortRules() {
    _rules.sort((a, b) {
      // Active rules first
      if (a.isActive && !b.isActive) return -1;
      if (!a.isActive && b.isActive) return 1;
      
      // Then by time
      if (a.time != null && b.time != null) {
        return a.time!.compareTo(b.time!);
      }
      
      return 0;
    });
  }

  /// Start monitoring for scheduled status changes
  void _startMonitoring() {
    _stopMonitoring();
    
    // Check every minute for scheduled status changes
    _checkTimer = Timer.periodic(
      const Duration(minutes: 1),
      (_) => _checkScheduledChanges(),
    );
    
    // Also check immediately
    _checkScheduledChanges();
  }

  /// Stop monitoring
  void _stopMonitoring() {
    _checkTimer?.cancel();
    _checkTimer = null;
  }

  /// Check if any scheduled status changes should be applied
  Future<void> _checkScheduledChanges() async {
    if (!_isEnabled) return;

    final now = DateTime.now();
    final currentTime = TimeOfDay.fromDateTime(now);
    final currentDay = now.weekday;

    for (final rule in _rules) {
      if (!rule.isActive) continue;

      bool shouldApply = false;

      // Check time-based rule
      if (rule.time != null) {
        final ruleTime = rule.time!;
        
        // Check if current time matches rule time (within 1 minute)
        if (currentTime.hour == ruleTime.hour && 
            currentTime.minute == ruleTime.minute) {
          
          // Check day condition
          if (rule.daysOfWeek.isEmpty || rule.daysOfWeek.contains(currentDay)) {
            shouldApply = true;
          }
        }
      }

      if (shouldApply) {
        try {
          await _statusService.updateStatus(
            rule.targetStatus,
            rule.customMessage ?? 'Scheduled status change',
          );
          
          debugPrint('[ScheduledStatusService] Applied rule: ${rule.name}');
        } catch (e) {
          debugPrint('[ScheduledStatusService] Error applying rule: $e');
        }
      }
    }
  }

  /// Initialize the service (call in app startup)
  Future<void> initialize() async {
    await loadRules();
    if (_isEnabled) {
      _startMonitoring();
    }
  }

  /// Dispose the service (call in app shutdown)
  void dispose() {
    _stopMonitoring();
  }
}
