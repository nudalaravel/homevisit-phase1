import 'package:flutter/foundation.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'api_service.dart';
import 'storage_service.dart';
import 'status_service.dart';
import '../models/user_status.dart';
import '../models/notification_settings.dart';

/// Background message handler (must be top-level function)
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  debugPrint('Handling background message: ${message.messageId}');
}

/// Push Notification Service with Firebase Cloud Messaging
/// 
/// Setup Instructions:
/// 
/// 1. Firebase Console Setup:
///    - Create project at https://console.firebase.google.com
///    - Add Android app (download google-services.json to android/app/)
///    - Add iOS app (download GoogleService-Info.plist to ios/Runner/)
/// 
/// 2. Android Configuration:
///    a. android/build.gradle:
///       dependencies {
///         classpath 'com.google.gms:google-services:4.4.0'
///       }
///    
///    b. android/app/build.gradle:
///       apply plugin: 'com.google.gms.google-services'
///    
///    c. android/app/src/main/AndroidManifest.xml:
///       <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
/// 
/// 3. iOS Configuration:
///    a. Add GoogleService-Info.plist to ios/Runner/ in Xcode
///    b. Enable Push Notifications capability in Xcode
///    c. Add to ios/Runner/Info.plist:
///       <key>FirebaseAppDelegateProxyEnabled</key>
///       <false/>
/// 
/// 4. Usage:
///    final notificationService = NotificationService();
///    await notificationService.initialize();
///    final token = notificationService.fcmToken;

class NotificationService {
  final ApiService _api = ApiService();
  final StorageService _storage = StorageService();
  final FirebaseMessaging _fcm = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();
  
  String? _fcmToken;
  bool _initialized = false;

  /// Get current FCM token
  String? get fcmToken => _fcmToken;

  /// Check if service is initialized
  bool get isInitialized => _initialized;

  /// Initialize push notifications
  Future<void> initialize() async {
    if (_initialized) return;

    try {
      // Initialize Firebase
      await Firebase.initializeApp();

      // Register background message handler
      FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

      // Request notification permissions
      final settings = await _fcm.requestPermission(
        alert: true,
        badge: true,
        sound: true,
        provisional: false,
      );

      if (settings.authorizationStatus != AuthorizationStatus.authorized) {
        debugPrint('User declined notification permission');
        return;
      }

      debugPrint('User granted notification permission');

      // Initialize local notifications
      await _initializeLocalNotifications();

      // Get FCM token
      _fcmToken = await _fcm.getToken();
      if (_fcmToken != null) {
        debugPrint('FCM Token: $_fcmToken');
        await _storage.saveString('fcm_token', _fcmToken!);
        await _sendTokenToServer(_fcmToken!);
      }

      // Listen for token refresh
      _fcm.onTokenRefresh.listen((newToken) {
        _fcmToken = newToken;
        _storage.saveString('fcm_token', newToken);
        _sendTokenToServer(newToken);
      });

      // Setup message handlers
      _setupMessageHandlers();

      _initialized = true;
      debugPrint('Notification service initialized successfully');
    } catch (e) {
      debugPrint('Failed to initialize notifications: $e');
    }
  }

  /// Initialize local notifications
  Future<void> _initializeLocalNotifications() async {
    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );
    const initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _localNotifications.initialize(
      initSettings,
      onDidReceiveNotificationResponse: _onNotificationTapped,
    );

    // Create Android notification channel
    const androidChannel = AndroidNotificationChannel(
      'nua_chat_channel',
      'NUA Chat Messages',
      description: 'Notifications for new messages',
      importance: Importance.high,
      playSound: true,
    );

    await _localNotifications
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(androidChannel);
  }

  /// Setup message handlers
  void _setupMessageHandlers() {
    // Handle foreground messages
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      debugPrint('Received foreground message: ${message.messageId}');
      _showLocalNotification(message);
    });

    // Handle notification tap when app is in background
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      debugPrint('Notification tapped (background): ${message.messageId}');
      _handleNotificationData(message.data);
    });

    // Handle notification tap when app is terminated
    _fcm.getInitialMessage().then((RemoteMessage? message) {
      if (message != null) {
        debugPrint('App opened from terminated state: ${message.messageId}');
        _handleNotificationData(message.data);
      }
    });
  }

  /// Check if notification should be shown based on current status
  Future<bool> _shouldShowNotification(RemoteMessage message) async {
    try {
      // Get current user status
      final statusService = StatusService();
      final currentStatus = await statusService.getCurrentStatus();
      
      // Get notification settings for current status
      final settings = currentStatus.notificationSettings;
      
      // Check if notifications are completely muted for this status
      if (settings.muteAll) {
        debugPrint('[NotificationService] Notifications muted for status: ${currentStatus.type.name}');
        return false;
      }
      
      // Check message priority from notification data
      final data = message.data;
      final isPriority = data['priority'] == 'high' || 
                        data['type'] == 'mention' || 
                        data['type'] == 'call' ||
                        data['type'] == 'nudge';
      
      // Allow priority notifications even in Busy/DND status
      if (isPriority && settings.allowPriority) {
        debugPrint('[NotificationService] Allowing priority notification');
        return true;
      }
      
      // Check if message notifications are allowed
      if (data['type'] == 'message' && !settings.allowMessages) {
        debugPrint('[NotificationService] Message notifications disabled for status');
        return false;
      }
      
      return true;
    } catch (e) {
      debugPrint('[NotificationService] Error checking notification settings: $e');
      // Default to showing notification on error
      return true;
    }
  }

  /// Show local notification for foreground messages
  Future<void> _showLocalNotification(RemoteMessage message) async {
    final notification = message.notification;
    if (notification == null) return;
    
    // Check if notification should be shown based on status
    final shouldShow = await _shouldShowNotification(message);
    if (!shouldShow) {
      debugPrint('[NotificationService] Notification suppressed due to status settings');
      return;
    }

    const androidDetails = AndroidNotificationDetails(
      'nua_chat_channel',
      'NUA Chat Messages',
      channelDescription: 'Notifications for new messages',
      importance: Importance.high,
      priority: Priority.high,
      showWhen: true,
      icon: '@mipmap/ic_launcher',
    );

    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    const details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _localNotifications.show(
      notification.hashCode,
      notification.title,
      notification.body,
      details,
      payload: message.data['chat_id'],
    );
  }

  /// Handle notification tap
  void _onNotificationTapped(NotificationResponse response) {
    if (response.payload != null) {
      debugPrint('Notification tapped with chat_id: ${response.payload}');
      _handleNotificationData({'chat_id': response.payload!});
    }
  }

  /// Handle notification data (navigate to chat)
  void _handleNotificationData(Map<String, dynamic> data) {
    // TODO: Implement navigation to chat screen
    // This should be called from main.dart with proper navigation context
    if (data.containsKey('chat_id')) {
      final chatId = data['chat_id'];
      debugPrint('Navigate to chat: $chatId');
      // Example: Get.toNamed('/chat', arguments: chatId);
      // Or: navigationService.navigateToChat(chatId);
    }
  }

  /// Send FCM token to backend
  Future<void> _sendTokenToServer(String token) async {
    try {
      await _api.post('/users/fcm-token', body: {
        'token': token,
        'platform': defaultTargetPlatform.name,
      });
      debugPrint('FCM token sent to server');
    } catch (e) {
      debugPrint('Failed to send FCM token: $e');
    }
  }

  /// Delete FCM token (call on logout)
  Future<void> deleteToken() async {
    try {
      if (_fcmToken != null) {
        await _api.delete('/users/fcm-token');
        await _fcm.deleteToken();
        await _storage.remove('fcm_token');
        _fcmToken = null;
        debugPrint('FCM token deleted');
      }
    } catch (e) {
      debugPrint('Failed to delete FCM token: $e');
    }
  }

  /// Get saved FCM token from storage
  Future<String?> getSavedToken() async {
    return await _storage.getString('fcm_token');
  }
}
