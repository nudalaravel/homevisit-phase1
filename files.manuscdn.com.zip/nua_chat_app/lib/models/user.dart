import 'user_status.dart';

class User {
  final String id;
  final String email;
  final String name;
  final String? avatar;
  final String? bio;
  final String status; // Keep for backward compatibility
  final String role;
  final DateTime createdAt;
  final DateTime updatedAt;
  final DateTime? lastSeen;
  
  // MSN-style features
  final UserStatus? userStatus;
  final String? personalMessage;

  User({
    required this.id,
    required this.email,
    required this.name,
    this.avatar,
    this.bio,
    required this.status,
    required this.role,
    required this.createdAt,
    required this.updatedAt,
    this.lastSeen,
    this.userStatus,
    this.personalMessage,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'] as String,
      email: json['email'] as String,
      name: json['name'] as String,
      avatar: json['avatar'] as String?,
      bio: json['bio'] as String?,
      status: json['status'] as String? ?? 'active',
      role: json['role'] as String? ?? 'user',
      createdAt: DateTime.parse(json['created_at'] as String),
      updatedAt: DateTime.parse(json['updated_at'] as String),
      lastSeen: json['last_seen'] != null 
          ? DateTime.parse(json['last_seen'] as String) 
          : null,
      userStatus: json['user_status'] != null 
          ? UserStatus.fromJson(json['user_status']) 
          : null,
      personalMessage: json['personal_message'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'email': email,
      'name': name,
      'avatar': avatar,
      'bio': bio,
      'status': status,
      'role': role,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
      'last_seen': lastSeen?.toIso8601String(),
      'user_status': userStatus?.toJson(),
      'personal_message': personalMessage,
    };
  }

  User copyWith({
    String? id,
    String? email,
    String? name,
    String? avatar,
    String? bio,
    String? status,
    String? role,
    DateTime? createdAt,
    DateTime? updatedAt,
    DateTime? lastSeen,
    UserStatus? userStatus,
    String? personalMessage,
  }) {
    return User(
      id: id ?? this.id,
      email: email ?? this.email,
      name: name ?? this.name,
      avatar: avatar ?? this.avatar,
      bio: bio ?? this.bio,
      status: status ?? this.status,
      role: role ?? this.role,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      lastSeen: lastSeen ?? this.lastSeen,
      userStatus: userStatus ?? this.userStatus,
      personalMessage: personalMessage ?? this.personalMessage,
    );
  }
  
  // Get MSN status display
  String get msnStatusIcon => userStatus?.status.icon ?? '🟢';
  String get msnStatusName => userStatus?.status.displayName ?? 'Available';
  String get msnCustomMessage => userStatus?.customMessage ?? personalMessage ?? '';

  bool get isOnline {
    if (lastSeen == null) return false;
    final difference = DateTime.now().difference(lastSeen!);
    return difference.inMinutes < 5;
  }
}
