import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import '../../models/user.dart';
import '../../models/chat.dart';
import '../../models/message.dart';
import '../../providers/chat_provider.dart';
import '../../providers/auth_provider.dart';
import '../../utils/app_theme.dart';
import '../../widgets/message_bubble.dart';
import '../../widgets/image_message_bubble.dart';
import '../../widgets/file_message_bubble.dart';
import '../../widgets/voice_message_bubble.dart';
import '../../widgets/voice_recorder.dart';
import '../../widgets/message_reactions.dart';
import '../../widgets/reply_message_preview.dart';
import '../../services/file_service.dart';
import '../../services/moderation_service.dart';
import 'package:flutter/services.dart';
import '../group/group_info_screen.dart';
import '../../services/group_service.dart';
import 'media_gallery_screen.dart';
import 'forward_message_screen.dart';
import '../../widgets/emoticon_picker.dart';
import '../../widgets/nudge_button.dart';

class ChatScreen extends StatefulWidget {
  final Chat chat;

  const ChatScreen({super.key, required this.chat});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _messageController = TextEditingController();
  final _scrollController = ScrollController();
  final _imagePicker = ImagePicker();
  final _fileService = FileService();
  bool _isTyping = false;
  bool _isUploading = false;
  bool _isRecording = false;
  Message? _replyingTo;

  @override
  void initState() {
    super.initState();
    _loadMessages();
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _loadMessages() async {
    final chatProvider = Provider.of<ChatProvider>(context, listen: false);
    await chatProvider.loadMessages(widget.chat.id);
  }

  Future<void> _sendMessage() async {
    final text = _messageController.text.trim();
    if (text.isEmpty) return;

    final chatProvider = Provider.of<ChatProvider>(context, listen: false);
    final replyToId = _replyingTo?.id;
    _messageController.clear();
    setState(() {
      _replyingTo = null;
    });

    final success = await chatProvider.sendMessage(
      widget.chat.id,
      text,
      replyToId: replyToId,
    );
    
    if (success) {
      _scrollToBottom();
    }
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        0,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  void _showAttachmentOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_library, color: AppTheme.primaryColor),
              title: const Text('Photo from Gallery'),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.gallery);
              },
            ),
            ListTile(
              leading: const Icon(Icons.camera_alt, color: AppTheme.primaryColor),
              title: const Text('Take Photo'),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.camera);
              },
            ),
            ListTile(
              leading: const Icon(Icons.insert_drive_file, color: AppTheme.primaryColor),
              title: const Text('Document'),
              onTap: () {
                Navigator.pop(context);
                _pickFile();
              },
            ),
            ListTile(
              leading: const Icon(Icons.mic, color: AppTheme.primaryColor),
              title: const Text('Voice Message'),
              onTap: () {
                Navigator.pop(context);
                _startVoiceRecording();
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? image = await _imagePicker.pickImage(
        source: source,
        maxWidth: 1920,
        maxHeight: 1920,
        imageQuality: 85,
      );

      if (image != null) {
        await _uploadAndSendFile(File(image.path), 'image');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to pick image: ${e.toString()}'),
            backgroundColor: AppTheme.errorColor,
          ),
        );
      }
    }
  }

  Future<void> _pickFile() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.any,
        allowMultiple: false,
      );

      if (result != null && result.files.isNotEmpty) {
        final file = File(result.files.first.path!);
        await _uploadAndSendFile(file, 'file');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to pick file: ${e.toString()}'),
            backgroundColor: AppTheme.errorColor,
          ),
        );
      }
    }
  }

  Future<void> _uploadAndSendFile(File file, String type) async {
    setState(() {
      _isUploading = true;
    });

    try {
      // Upload file to server
      final fileUrl = await _fileService.uploadFile(file);
      final fileName = file.path.split('/').last;
      final fileSize = await file.length();

      // Send message with file
      final chatProvider = Provider.of<ChatProvider>(context, listen: false);
      await chatProvider.sendMessage(
        widget.chat.id,
        '', // Optional caption
        type: type,
        fileUrl: fileUrl,
        fileName: fileName,
        fileSize: fileSize,
      );

      _scrollToBottom();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to send file: ${e.toString()}'),
            backgroundColor: AppTheme.errorColor,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isUploading = false;
        });
      }
    }
  }

  void _startVoiceRecording() {
    setState(() {
      _isRecording = true;
    });
  }

  Future<void> _sendVoiceMessage(String audioPath) async {
    setState(() {
      _isRecording = false;
      _isUploading = true;
    });

    try {
      // Upload audio file
      final file = File(audioPath);
      final audioUrl = await _fileService.uploadFile(file);
      final fileName = file.path.split('/').last;
      final fileSize = await file.length();

      // Send voice message
      final chatProvider = Provider.of<ChatProvider>(context, listen: false);
      await chatProvider.sendMessage(
        widget.chat.id,
        '',
        type: 'audio',
        fileUrl: audioUrl,
        fileName: fileName,
        fileSize: fileSize,
      );

      _scrollToBottom();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to send voice message: ${e.toString()}'),
            backgroundColor: AppTheme.errorColor,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isUploading = false;
        });
      }
    }
  }

  void _cancelVoiceRecording() {
    setState(() {
      _isRecording = false;
    });
  }

  Future<void> _toggleReaction(Message message, String emoji) async {
    try {
      final chatProvider = Provider.of<ChatProvider>(context, listen: false);
      await chatProvider.toggleReaction(message.id, emoji);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to react: ${e.toString()}'),
            backgroundColor: AppTheme.errorColor,
          ),
        );
      }
    }
  }

  void _showReactionPicker(Message message) {
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'React to message',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              Wrap(
                spacing: 16,
                runSpacing: 16,
                children: ['👍', '❤️', '😂', '😮', '😢', '🙏', '👏', '🔥'].map((emoji) {
                  return GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                      _toggleReaction(message, emoji);
                    },
                    child: Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        color: AppTheme.surfaceColor,
                        borderRadius: BorderRadius.circular(24),
                      ),
                      child: Center(
                        child: Text(
                          emoji,
                          style: const TextStyle(fontSize: 24),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }

  void _showMessageActions(Message message, bool isMe) {
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.add_reaction, color: AppTheme.primaryColor),
              title: const Text('React'),
              onTap: () {
                Navigator.pop(context);
                _showReactionPicker(message);
              },
            ),
            ListTile(
              leading: const Icon(Icons.forward, color: AppTheme.primaryColor),
              title: const Text('Forward'),
              onTap: () {
                Navigator.pop(context);
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => ForwardMessageScreen(
                      messages: [message],
                    ),
                  ),
                );
              },
            ),
            if (message.type == 'text') ...[ 
              ListTile(
                leading: const Icon(Icons.copy),
                title: const Text('Copy'),
                onTap: () {
                  Clipboard.setData(ClipboardData(text: message.content));
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Message copied')),
                  );
                },
              ),
            ],
            if (isMe) ...[ 
              ListTile(
                leading: const Icon(Icons.delete, color: AppTheme.errorColor),
                title: const Text('Delete', style: TextStyle(color: AppTheme.errorColor)),
                onTap: () {
                  Navigator.pop(context);
                  _deleteMessage(message);
                },
              ),
            ] else ...[ 
              ListTile(
                leading: const Icon(Icons.report, color: AppTheme.errorColor),
                title: const Text('Report'),
                onTap: () {
                  Navigator.pop(context);
                  _reportMessage(message);
                },
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _deleteMessage(Message message) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Message'),
        content: const Text('Are you sure you want to delete this message?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete', style: TextStyle(color: AppTheme.errorColor)),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      final chatProvider = Provider.of<ChatProvider>(context, listen: false);
      final success = await chatProvider.deleteMessage(widget.chat.id, message.id);
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(success ? 'Message deleted' : 'Failed to delete message'),
            backgroundColor: success ? AppTheme.secondaryColor : AppTheme.errorColor,
          ),
        );
      }
    }
  }

  Future<void> _reportMessage(Message message) async {
    final reasonController = TextEditingController();
    final descriptionController = TextEditingController();

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Report Message'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: reasonController,
              decoration: const InputDecoration(
                labelText: 'Reason',
                hintText: 'e.g., Spam, Harassment',
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: descriptionController,
              decoration: const InputDecoration(
                labelText: 'Description (optional)',
                hintText: 'Additional details',
              ),
              maxLines: 3,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Report', style: TextStyle(color: AppTheme.errorColor)),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      try {
        final moderationService = ModerationService();
        await moderationService.reportMessage(
          messageId: message.id,
          reason: reasonController.text.trim(),
          description: descriptionController.text.trim(),
        );
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Message reported'),
              backgroundColor: AppTheme.secondaryColor,
            ),
          );
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Failed to report: ${e.toString()}'),
              backgroundColor: AppTheme.errorColor,
            ),
          );
        }
      }
    }

    reasonController.dispose();
    descriptionController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final currentUserId = authProvider.currentUser?.id ?? '';
    final displayName = widget.chat.getDisplayName(currentUserId);

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            CircleAvatar(
              radius: 18,
              backgroundColor: AppTheme.primaryColor.withOpacity(0.1),
              child: Text(
                displayName[0].toUpperCase(),
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primaryColor,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      Text(
                        displayName,
                        style: const TextStyle(fontSize: 16),
                      ),
                      if (!widget.chat.isGroup && widget.chat.otherUser != null) ..[
                        const SizedBox(width: 6),
                        Text(
                          widget.chat.otherUser!.msnStatusIcon,
                          style: const TextStyle(fontSize: 14),
                        ),
                      ],
                    ],
                  ),
                  if (!widget.chat.isGroup && widget.chat.otherUser != null)
                    Text(
                      widget.chat.otherUser!.msnCustomMessage.isNotEmpty
                          ? widget.chat.otherUser!.msnCustomMessage
                          : widget.chat.otherUser!.msnStatusName,
                      style: const TextStyle(
                        fontSize: 12,
                        fontStyle: FontStyle.italic,
                        color: Colors.white70,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.photo_library),
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => MediaGalleryScreen(
                    chatId: widget.chat.id,
                    chatName: displayName,
                  ),
                ),
              );
            },
          ),
          if (widget.chat.isGroup)
            IconButton(
              icon: const Icon(Icons.info_outline),
              onPressed: () async {
                try {
                  final groupService = GroupService();
                  final group = await groupService.getGroup(widget.chat.id);
                  if (mounted) {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => GroupInfoScreen(group: group),
                      ),
                    );
                  }
                } catch (e) {
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Failed to load group info: ${e.toString()}'),
                        backgroundColor: AppTheme.errorColor,
                      ),
                    );
                  }
                }
              },
            ),
        ],
      ),
      body: Column(
        children: [
          // Messages List
          Expanded(
            child: Consumer<ChatProvider>(
              builder: (context, chatProvider, _) {
                final messages = chatProvider.getMessages(widget.chat.id);

                if (messages.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.chat_bubble_outline,
                          size: 64,
                          color: AppTheme.textHintColor,
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'No messages yet',
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            color: AppTheme.textSecondaryColor,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Send a message to start the conversation',
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: AppTheme.textHintColor,
                          ),
                        ),
                      ],
                    ),
                  );
                }

                return ListView.builder(
                  controller: _scrollController,
                  reverse: true,
                  padding: const EdgeInsets.all(16),
                  itemCount: messages.length,
                  itemBuilder: (context, index) {
                    final message = messages[index];
                    final isMe = message.sender.id == currentUserId;

                    // Wrap message bubbles with long-press menu
                    Widget messageBubble;
                    if (message.type == 'image') {
                      messageBubble = ImageMessageBubble(
                        message: message,
                        isMe: isMe,
                      );
                    } else if (message.type == 'audio') {
                      messageBubble = VoiceMessageBubble(
                        message: message,
                        isMe: isMe,
                      );
                    } else if (message.type == 'file' || message.type == 'video') {
                      messageBubble = FileMessageBubble(
                        message: message,
                        isMe: isMe,
                      );
                    } else {
                      messageBubble = MessageBubble(
                        message: message,
                        isMe: isMe,
                      );
                    }

                    return Dismissible(
                      key: Key(message.id),
                      direction: DismissDirection.endToStart,
                      confirmDismiss: (direction) async {
                        setState(() {
                          _replyingTo = message;
                        });
                        return false; // Don't actually dismiss
                      },
                      background: Container(
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 20),
                        child: const Icon(Icons.reply, color: AppTheme.primaryColor),
                      ),
                      child: GestureDetector(
                        onLongPress: () => _showMessageActions(message, isMe),
                        child: Column(
                        crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                        children: [
                          messageBubble,
                          if (message.reactions != null && message.reactions!.isNotEmpty)
                            Padding(
                              padding: const EdgeInsets.only(top: 4, left: 8, right: 8),
                              child: MessageReactions(
                                reactions: message.reactions!,
                                currentUserId: Provider.of<AuthProvider>(context, listen: false).user?.id ?? '',
                                onReactionTap: (emoji) {
                                  _toggleReaction(message, emoji);
                                },
                              ),
                            ),
                        ],
                      ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          // Reply Preview
          if (_replyingTo != null)
            ReplyMessagePreview(
              message: _replyingTo!,
              onCancel: () {
                setState(() {
                  _replyingTo = null;
                });
              },
              onTap: () {
                // Scroll to replied message
                final messages = Provider.of<ChatProvider>(context, listen: false)
                    .getMessages(widget.chat.id);
                final index = messages.indexWhere((m) => m.id == _replyingTo!.id);
                if (index != -1 && _scrollController.hasClients) {
                  _scrollController.animateTo(
                    index * 100.0, // Approximate item height
                    duration: const Duration(milliseconds: 300),
                    curve: Curves.easeOut,
                  );
                }
              },
            ),
          // Message Input or Voice Recorder
          _isRecording
              ? VoiceRecorder(
                  onRecordComplete: (filePath, duration) {
                    _sendVoiceMessage(filePath);
                  },
                )
              : Container(
                  decoration: BoxDecoration(
                    color: AppTheme.surfaceColor,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 10,
                        offset: const Offset(0, -2),
                      ),
                    ],
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: SafeArea(
                    child: Row(
                      children: [
                        // Nudge Button (MSN-style)
                        if (!widget.chat.isGroup)
                          NudgeButton(
                            chatId: widget.chat.id,
                            recipientId: widget.chat.otherUser?.id ?? '',
                          ),
                        // Emoticon Picker Button (MSN-style)
                        IconButton(
                          icon: const Icon(Icons.emoji_emotions_outlined),
                          onPressed: () {
                            showModalBottomSheet(
                              context: context,
                              isScrollControlled: true,
                              builder: (context) => SizedBox(
                                height: MediaQuery.of(context).size.height * 0.6,
                                child: EmoticonPicker(
                                  onEmoticonSelected: (emoticon) {
                                    Navigator.pop(context);
                                    _messageController.text += emoticon.code;
                                  },
                                ),
                              ),
                            );
                          },
                        ),
                        // Attachment Button
                        IconButton(
                          icon: const Icon(Icons.attach_file),
                          onPressed: _isUploading ? null : () => _showAttachmentOptions(context),
                        ),
                        // Text Input
                        Expanded(
                          child: TextField(
                            controller: _messageController,
                            decoration: InputDecoration(
                              hintText: 'Type a message...',
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(24),
                                borderSide: BorderSide.none,
                              ),
                              filled: true,
                              fillColor: AppTheme.backgroundColor,
                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 20,
                                vertical: 10,
                              ),
                            ),
                            maxLines: null,
                            textCapitalization: TextCapitalization.sentences,
                            onChanged: (text) {
                              if (text.isNotEmpty && !_isTyping) {
                                setState(() {
                                  _isTyping = true;
                                });
                                final chatProvider = Provider.of<ChatProvider>(context, listen: false);
                                chatProvider.sendTypingIndicator(widget.chat.id);
                              } else if (text.isEmpty && _isTyping) {
                                setState(() {
                                  _isTyping = false;
                                });
                              }
                            },
                          ),
                        ),
                        const SizedBox(width: 8),
                        // Send Button
                        CircleAvatar(
                          backgroundColor: AppTheme.primaryColor,
                          child: IconButton(
                            icon: const Icon(Icons.send, color: Colors.white),
                            onPressed: _sendMessage,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
        ],
      ),
    );
  }
}
