import 'package:flutter/material.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../models/chat.dart';
import '../utils/app_theme.dart';
import '../screens/chat/chat_screen.dart';

class ChatListItem extends StatelessWidget {
  final Chat chat;
  final String currentUserId;

  const ChatListItem({
    super.key,
    required this.chat,
    required this.currentUserId,
  });

  @override
  Widget build(BuildContext context) {
    final displayName = chat.getDisplayName(currentUserId);
    final displayAvatar = chat.getDisplayAvatar(currentUserId);
    final isGroup = chat.isGroup;
    final lastMessage = chat.lastMessage;
    final hasUnread = chat.unreadCount > 0;

    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      leading: Stack(
        children: [
          CircleAvatar(
            radius: 28,
            backgroundColor: AppTheme.primaryColor.withOpacity(0.1),
            backgroundImage: displayAvatar != null
                ? NetworkImage(displayAvatar)
                : null,
            child: displayAvatar == null
                ? isGroup
                    ? const Icon(
                        Icons.group,
                        size: 28,
                        color: AppTheme.primaryColor,
                      )
                    : Text(
                        displayName[0].toUpperCase(),
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: AppTheme.primaryColor,
                        ),
                      )
                : null,
          ),
          // MSN Status indicator (bottom-right)
          if (!isGroup && chat.otherUser != null)
            Positioned(
              right: 0,
              bottom: 0,
              child: Container(
                padding: const EdgeInsets.all(2),
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 1.5),
                ),
                child: Text(
                  chat.otherUser!.msnStatusIcon,
                  style: const TextStyle(fontSize: 12),
                ),
              ),
            ),
          // Unread indicator (top-right)
          if (hasUnread)
            Positioned(
              right: 0,
              top: 0,
              child: Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  color: AppTheme.secondaryColor,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 2),
                ),
              ),
            ),
        ],
      ),
      title: Row(
        children: [
          Expanded(
            child: Text(
              displayName,
              style: TextStyle(
                fontWeight: hasUnread ? FontWeight.bold : FontWeight.w500,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          if (lastMessage != null)
            Text(
              timeago.format(lastMessage.createdAt, locale: 'en_short'),
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: hasUnread
                    ? AppTheme.primaryColor
                    : AppTheme.textSecondaryColor,
                fontWeight: hasUnread ? FontWeight.w600 : FontWeight.normal,
              ),
            ),
        ],
      ),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Personal message (MSN-style)
          if (!isGroup && chat.otherUser != null && chat.otherUser!.msnCustomMessage.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 2),
              child: Text(
                chat.otherUser!.msnCustomMessage,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: AppTheme.textSecondaryColor.withOpacity(0.8),
                  fontStyle: FontStyle.italic,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          // Last message
          Row(
            children: [
              Expanded(
                child: Text(
                  lastMessage?.content ?? 'No messages yet',
                  style: TextStyle(
                    color: hasUnread
                        ? AppTheme.textPrimaryColor
                        : AppTheme.textSecondaryColor,
                    fontWeight: hasUnread ? FontWeight.w600 : FontWeight.normal,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              if (hasUnread)
                Container(
                  margin: const EdgeInsets.only(left: 8),
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryColor,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    chat.unreadCount > 99 ? '99+' : '${chat.unreadCount}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => ChatScreen(chat: chat),
          ),
        );
      },
    );
  }
}
