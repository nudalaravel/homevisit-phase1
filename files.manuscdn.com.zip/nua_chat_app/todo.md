# NUA Chat App - Development TODO

## Phase 1: Project Setup & Architecture
- [x] Initialize Flutter project
- [x] Setup project structure (folders: models, services, screens, widgets, utils)
- [x] Add dependencies (http, provider/riverpod, shared_preferences, etc.)
- [x] Create API service layer for NUA Backend
- [x] Setup constants and configuration
- [x] Create data models (User, Chat, Message)
- [x] Create theme and styling

## Phase 2: Authentication & Onboarding
- [x] Splash screen
- [ ] Onboarding/Welcome screen (skipped - direct to login)
- [x] Login screen
- [x] Register screen
- [x] Forgot password screen
- [x] Authentication service integration with NUA Backend API
- [x] Token management and storage
- [x] Auto-login functionality

## Phase 3: Chat List & Messaging UI
- [x] Home screen with chat list
- [x] Chat room screen
- [x] Message bubble widgets
- [x] Send message functionality
- [x] Image/file upload in chat
- [x] Chat list API integration
- [x] Message history API integration
- [x] Pull-to-refresh for chat list

## Phase 4: User Profile & Settings
- [x] User profile screen
- [x] Edit profile screen
- [x] Settings screen
- [x] Logout functionality
- [x] Profile API integration
- [x] Update profile API integration

## Phase 5: Real-time Features
- [x] WebSocket connection for real-time messages
- [ ] Push notifications setup (requires platform config)
- [x] Online/offline status (WebSocket ready)
- [x] Typing indicators
- [x] Message read receipts (via WebSocket)
- [x] Unread message count

## Phase 6: Additional Features
- [x] Image message bubbles
- [x] File message bubbles
- [x] Image picker (gallery & camera)
- [x] File picker
- [x] File upload service
- [x] Message type support (text, image, file, video, audio)
- [x] Search functionality (users)
- [x] Block/Report users
- [x] Delete messages
- [x] Report messages
- [x] Message actions (copy, delete, report)
- [x] User profile detail screen
- [x] User discovery via search
- [ ] Friend requests (not applicable for chat app) (if applicable)

## Phase 7: Testing & Polish
- [ ] Error handling
- [ ] Loading states
- [ ] Empty states
- [ ] Network error handling
- [ ] Form validation
- [ ] UI/UX polish
- [ ] Performance optimization
- [ ] Test on Android
- [ ] Test on iOS

## Phase 8: Deployment
- [ ] Build APK for Android
- [ ] Build IPA for iOS
- [ ] Push to GitHub
- [ ] Documentation

## Phase 8: Advanced Features
- [x] Push Notifications (Firebase setup guide ready)
- [x] Group Chats (models & services ready)
  - [x] Group model
  - [x] Group service (create, update, members, admins)
  - [ ] Create group UI
  - [ ] Group info screen UI
  - [ ] Add/remove members UI
- [x] Message Reactions (widgets ready)
  - [x] Reaction display widget
  - [x] Reaction picker
  - [ ] Integrate into chat screen
- [x] Voice Messages (recorder widget ready)
  - [x] Voice recorder widget
  - [ ] Audio player widget
  - [ ] Integrate into chat screen
- [ ] Message Search in chat (backend needed)
- [ ] Message forwarding
- [ ] Media gallery view
- [ ] Chat settings (mute, archive)

## Phase 9: Complete Remaining Features
- [x] Group Chat UI
  - [x] Create group screen
  - [x] Group info screen
  - [x] Add members screen
  - [x] Member management
  - [x] Group settings (leave/delete)
- [x] Voice Messages Integration
  - [x] Audio player widget
  - [x] Integrate recorder in chat
  - [x] Voice message bubble
  - [x] Playback controls
- [x] Reaction Picker Integration
  - [x] Add reaction button to messages
  - [x] Show reaction picker on long-press
  - [x] Display reactions on messages
  - [x] Handle reaction API calls
- [ ] Message Search (optional - requires backend support)
  - [ ] Search bar in chat screen
  - [ ] Search results display
  - [ ] Highlight search matches
  - [ ] Navigate to message
- [x] Media Gallery
  - [x] Gallery screen
  - [x] Show all images from chat
  - [x] Show all files from chat
  - [x] Download/share options
  - [x] Full-screen image viewer
  - [x] Tabbed interface (Images/Files/Videos)


## Phase 10: Essential Features (Priority 1)
- [x] Push Notifications
  - [x] Firebase Cloud Messaging setup
  - [x] Notification service implementation
  - [x] Handle notification taps
  - [x] Notification permissions
  - [x] Background notifications
  - [x] Local notifications
  - [x] Setup guide (FIREBASE_SETUP.md)
- [x] Message Reply/Quote
  - [x] Swipe to reply gesture
  - [x] Reply UI component
  - [x] Show quoted message
  - [x] Jump to original message
  - [x] Reply in groups
  - [x] Reply preview widget
- [x] Message Forwarding
  - [x] Select messages to forward
  - [x] Choose destination chats
  - [x] Forward to multiple chats
  - [x] Forward multiple messages
  - [x] Forward media

## Phase 11: Competitive Features (Priority 2)
- [x] Voice/Video Calls
  - [x] WebRTC integration
  - [x] Voice call UI
  - [x] Video call UI
  - [x] Call notifications (ready)
  - [ ] Call history (optional)
  - [x] Mute/unmute controls
  - [x] Camera switch
  - [x] Speaker toggle
- [x] Stories
  - [x] Create story (image)
  - [x] View stories
  - [x] Story viewer UI with timer
  - [x] Story expiration (24h)
  - [x] Story views list
  - [ ] Story privacy settings (optional)
  - [ ] Reply to stories (optional)
- [x] End-to-End Encryption
  - [x] Encryption library integration (RSA + AES)
  - [x] Key generation (2048-bit RSA)
  - [x] Key exchange protocol
  - [x] Message encryption
  - [x] Message decryption
  - [ ] Encryption indicators (optional UI)
  - [ ] Verify encryption keys (optional)

## Phase 12: MSN Features Implementation Review & Completion
- [x] Review existing MSN models (UserStatus, PersonalMessage, Nudge, Emoticon, AutoStatusRule, NotificationSettings)
- [x] Review existing MSN services (StatusService, EmoticonService, NudgeService)
- [x] Review existing MSN UI screens (StatusSelector, BioEditor, StatusHistory, AutoStatusSettings)
- [x] Review existing MSN widgets (EmoticonPicker, NudgeButton)
- [x] Integrate status selector into main UI (profile, settings)
- [x] Integrate bio editor into profile screen
- [x] Add status indicators to contact list and chat headers
- [x] Add bio display to user profiles
- [x] Integrate emoticon picker into message composer
- [x] Integrate nudge button into chat screen
- [x] Add MSN Features section to Settings
- [x] Update User model with userStatus and personalMessage fields
- [ ] Implement auto-away detection logic (requires background service)
- [ ] Implement scheduled status changes (requires background service)
- [ ] Implement notification muting by status (requires integration with NotificationService)
- [ ] Test all MSN features end-to-end
- [ ] Update documentation with MSN features guide
- [ ] Create user guide with screenshots

## Phase 13: Complete Remaining MSN Features
- [x] Implement auto-away detection background service
- [x] Implement scheduled status changes background service
- [x] Integrate notification muting with NotificationService
- [x] Add WebSocket listeners for real-time status updates (already exists)
- [x] Add error handling to StatusService (already exists)
- [x] Add error handling to EmoticonService (already exists)
- [x] Add error handling to NudgeService (already exists)
- [x] Add loading states to StatusSelectorScreen (already exists)
- [x] Add loading states to BioEditorScreen (already exists)
- [x] Add loading states to EmoticonPicker (already exists)
- [x] Create unit tests for UserStatus model
- [x] Create unit tests for AutoAwayService
- [x] Create unit tests for ScheduledStatusService
- [ ] Update MSN_FEATURES_IMPLEMENTATION_SUMMARY.md
- [ ] Create user guide with screenshots
