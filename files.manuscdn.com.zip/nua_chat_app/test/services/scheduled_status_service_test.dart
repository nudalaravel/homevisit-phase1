import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/material.dart';
import 'package:nua_chat_app/services/scheduled_status_service.dart';
import 'package:nua_chat_app/models/auto_status_rule.dart';
import 'package:nua_chat_app/models/user_status.dart';

void main() {
  group('ScheduledStatusService Tests', () {
    late ScheduledStatusService service;

    setUp(() {
      service = ScheduledStatusService();
    });

    tearDown(() {
      service.dispose();
    });

    test('Service should be enabled by default', () {
      expect(service.isEnabled, true);
    });

    test('Service should start with empty rules', () {
      expect(service.rules, isEmpty);
    });

    test('Adding a rule should increase rules count', () {
      final rule = AutoStatusRule(
        id: 'rule1',
        name: 'Morning Available',
        targetStatus: StatusType.available,
        time: const TimeOfDay(hour: 9, minute: 0),
        daysOfWeek: [1, 2, 3, 4, 5], // Weekdays
        isActive: true,
      );

      service.addRule(rule);
      expect(service.rules.length, 1);
      expect(service.rules.first.name, 'Morning Available');
    });

    test('Removing a rule should decrease rules count', () {
      final rule = AutoStatusRule(
        id: 'rule1',
        name: 'Test Rule',
        targetStatus: StatusType.away,
        time: const TimeOfDay(hour: 12, minute: 0),
        daysOfWeek: [],
        isActive: true,
      );

      service.addRule(rule);
      expect(service.rules.length, 1);

      service.removeRule('rule1');
      expect(service.rules, isEmpty);
    });

    test('Updating a rule should modify existing rule', () {
      final rule = AutoStatusRule(
        id: 'rule1',
        name: 'Original Name',
        targetStatus: StatusType.available,
        time: const TimeOfDay(hour: 9, minute: 0),
        daysOfWeek: [],
        isActive: true,
      );

      service.addRule(rule);

      final updatedRule = rule.copyWith(name: 'Updated Name');
      service.updateRule(updatedRule);

      expect(service.rules.first.name, 'Updated Name');
    });

    test('Service should be singleton', () {
      final service1 = ScheduledStatusService();
      final service2 = ScheduledStatusService();
      expect(identical(service1, service2), true);
    });

    test('Disabling service should stop monitoring', () {
      service.isEnabled = false;
      expect(service.isEnabled, false);
    });

    test('Enabling service should start monitoring', () {
      service.isEnabled = false;
      service.isEnabled = true;
      expect(service.isEnabled, true);
    });
  });

  group('ScheduledStatusService Rule Sorting Tests', () {
    late ScheduledStatusService service;

    setUp(() {
      service = ScheduledStatusService();
    });

    tearDown(() {
      service.dispose();
    });

    test('Active rules should be sorted before inactive rules', () {
      final activeRule = AutoStatusRule(
        id: 'active',
        name: 'Active Rule',
        targetStatus: StatusType.available,
        time: const TimeOfDay(hour: 10, minute: 0),
        daysOfWeek: [],
        isActive: true,
      );

      final inactiveRule = AutoStatusRule(
        id: 'inactive',
        name: 'Inactive Rule',
        targetStatus: StatusType.away,
        time: const TimeOfDay(hour: 9, minute: 0),
        daysOfWeek: [],
        isActive: false,
      );

      service.addRule(inactiveRule);
      service.addRule(activeRule);

      expect(service.rules.first.isActive, true);
      expect(service.rules.last.isActive, false);
    });

    test('Rules with earlier times should be sorted first', () {
      final morningRule = AutoStatusRule(
        id: 'morning',
        name: 'Morning',
        targetStatus: StatusType.available,
        time: const TimeOfDay(hour: 9, minute: 0),
        daysOfWeek: [],
        isActive: true,
      );

      final afternoonRule = AutoStatusRule(
        id: 'afternoon',
        name: 'Afternoon',
        targetStatus: StatusType.away,
        time: const TimeOfDay(hour: 14, minute: 0),
        daysOfWeek: [],
        isActive: true,
      );

      service.addRule(afternoonRule);
      service.addRule(morningRule);

      expect(service.rules.first.time!.hour, 9);
      expect(service.rules.last.time!.hour, 14);
    });
  });
}
