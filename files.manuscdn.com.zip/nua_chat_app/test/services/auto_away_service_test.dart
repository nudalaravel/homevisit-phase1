import 'package:flutter_test/flutter_test.dart';
import 'package:nua_chat_app/services/auto_away_service.dart';
import 'package:nua_chat_app/models/user_status.dart';

void main() {
  group('AutoAwayService Tests', () {
    late AutoAwayService service;

    setUp(() {
      service = AutoAwayService();
    });

    tearDown(() {
      service.dispose();
    });

    test('Service should be enabled by default', () {
      expect(service.isEnabled, true);
    });

    test('Service should have 5 minutes default threshold', () {
      expect(service.awayThreshold, const Duration(minutes: 5));
    });

    test('Setting threshold should update the value', () {
      service.awayThreshold = const Duration(minutes: 10);
      expect(service.awayThreshold, const Duration(minutes: 10));
    });

    test('Disabling service should stop monitoring', () {
      service.isEnabled = false;
      expect(service.isEnabled, false);
    });

    test('Enabling service should start monitoring', () {
      service.isEnabled = false;
      service.isEnabled = true;
      expect(service.isEnabled, true);
    });

    test('Recording activity should update last activity time', () {
      final beforeRecord = DateTime.now();
      service.recordActivity();
      // Activity should be recorded (no exception thrown)
      expect(service.isEnabled, true);
    });

    test('Service should be singleton', () {
      final service1 = AutoAwayService();
      final service2 = AutoAwayService();
      expect(identical(service1, service2), true);
    });
  });

  group('AutoAwayService Integration Tests', () {
    test('Service should initialize without errors', () {
      final service = AutoAwayService();
      expect(() => service.initialize(), returnsNormally);
    });

    test('Service should dispose without errors', () {
      final service = AutoAwayService();
      service.initialize();
      expect(() => service.dispose(), returnsNormally);
    });
  });
}
