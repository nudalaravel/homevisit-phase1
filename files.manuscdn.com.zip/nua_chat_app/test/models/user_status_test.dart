import 'package:flutter_test/flutter_test.dart';
import 'package:nua_chat_app/models/user_status.dart';

void main() {
  group('UserStatus Model Tests', () {
    test('StatusType enum should have correct display names', () {
      expect(StatusType.available.displayName, 'Available');
      expect(StatusType.away.displayName, 'Away');
      expect(StatusType.busy.displayName, 'Busy');
      expect(StatusType.beRightBack.displayName, 'Be Right Back');
      expect(StatusType.outToLunch.displayName, 'Out to Lunch');
      expect(StatusType.onThePhone.displayName, 'On the Phone');
      expect(StatusType.appearOffline.displayName, 'Appear Offline');
    });

    test('StatusType enum should have correct icons', () {
      expect(StatusType.available.icon, '🟢');
      expect(StatusType.away.icon, '🟡');
      expect(StatusType.busy.icon, '🔴');
      expect(StatusType.beRightBack.icon, '🔵');
      expect(StatusType.outToLunch.icon, '🍽️');
      expect(StatusType.onThePhone.icon, '📞');
      expect(StatusType.appearOffline.icon, '👻');
    });

    test('UserStatus should be created with default notification settings', () {
      final status = UserStatus(
        userId: 'user123',
        type: StatusType.available,
        customMessage: 'Hello world',
        lastActivity: DateTime.now(),
      );

      expect(status.userId, 'user123');
      expect(status.type, StatusType.available);
      expect(status.customMessage, 'Hello world');
      expect(status.notificationSettings, isNotNull);
      expect(status.notificationSettings.allowMessages, true);
    });

    test('UserStatus should serialize to JSON correctly', () {
      final now = DateTime.now();
      final status = UserStatus(
        userId: 'user123',
        type: StatusType.busy,
        customMessage: 'In a meeting',
        lastActivity: now,
      );

      final json = status.toJson();

      expect(json['userId'], 'user123');
      expect(json['status'], 'busy');
      expect(json['customMessage'], 'In a meeting');
      expect(json['lastActivity'], now.toIso8601String());
      expect(json['isOnline'], true);
    });

    test('UserStatus should deserialize from JSON correctly', () {
      final json = {
        'userId': 'user456',
        'status': 'away',
        'customMessage': 'BRB',
        'lastActivity': '2026-01-29T10:00:00.000Z',
        'isOnline': true,
      };

      final status = UserStatus.fromJson(json);

      expect(status.userId, 'user456');
      expect(status.type, StatusType.away);
      expect(status.customMessage, 'BRB');
      expect(status.isOnline, true);
    });

    test('NotificationSettings should have correct defaults for Available status', () {
      final settings = NotificationSettings.forStatus(StatusType.available);

      expect(settings.muteAll, false);
      expect(settings.allowMessages, true);
      expect(settings.allowPriority, true);
      expect(settings.playSound, true);
      expect(settings.showBanner, true);
    });

    test('NotificationSettings should mute for Busy status', () {
      final settings = NotificationSettings.forStatus(StatusType.busy);

      expect(settings.muteAll, false);
      expect(settings.allowMessages, false);
      expect(settings.allowPriority, true); // Priority still allowed
      expect(settings.playSound, false);
    });

    test('NotificationSettings should mute for Appear Offline status', () {
      final settings = NotificationSettings.forStatus(StatusType.appearOffline);

      expect(settings.muteAll, true);
      expect(settings.allowMessages, false);
      expect(settings.allowPriority, false);
      expect(settings.playSound, false);
      expect(settings.showBanner, false);
    });

    test('UserStatus copyWith should create new instance with updated fields', () {
      final original = UserStatus(
        userId: 'user123',
        type: StatusType.available,
        customMessage: 'Hello',
        lastActivity: DateTime.now(),
      );

      final updated = original.copyWith(
        type: StatusType.away,
        customMessage: 'Goodbye',
      );

      expect(updated.userId, original.userId);
      expect(updated.type, StatusType.away);
      expect(updated.customMessage, 'Goodbye');
      expect(updated.lastActivity, original.lastActivity);
    });

    test('UserStatus should handle null custom message', () {
      final status = UserStatus(
        userId: 'user123',
        type: StatusType.available,
        customMessage: null,
        lastActivity: DateTime.now(),
      );

      expect(status.customMessage, null);
      
      final json = status.toJson();
      expect(json['customMessage'], null);
    });

    test('StatusType should parse from string correctly', () {
      expect(StatusType.values.byName('available'), StatusType.available);
      expect(StatusType.values.byName('away'), StatusType.away);
      expect(StatusType.values.byName('busy'), StatusType.busy);
    });
  });
}
